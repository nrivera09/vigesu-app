// src/shared/config/apiConfig.ts

export const API_CONFIG = {
  BASE_URL: "https://ronnyruiz-001-site1.qtempurl.com/api",
};
