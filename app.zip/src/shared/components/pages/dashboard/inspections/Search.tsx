import React from "react";

const Search = () => {
  return (
    <div className=" w-full h-dvh  z-50 left-0 top-0 flex items-center justify-center">
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Magni sint vero
      delectus reiciendis placeat, consectetur eveniet aspernatur quia
      repellendus pariatur, exercitationem dignissimos veritatis consequatur
      repellat illum, ad laboriosam? Saepe, quos!
    </div>
  );
};

export default Search;
