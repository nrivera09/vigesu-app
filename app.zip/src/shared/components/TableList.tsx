import React from "react";
import { FaRegEdit, FaRegFilePdf } from "react-icons/fa";
import { FiPrinter, FiTrash2 } from "react-icons/fi";

const TableList = () => {
  return (
    <div className="overflow-x-auto">
      <table className="table table-md">
        <thead>
          <tr>
            <th>Sel</th>
            <th>Worker</th>
            <th>Status</th>
            <th>Sync Quickbook</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>
              <input type="checkbox" defaultChecked className="checkbox" />
            </th>
            <td className="truncate">Cy Ganderton</td>
            <td className="truncate">Quality Control Specialist </td>
            <td className="text-center">
              <input type="checkbox" defaultChecked className="checkbox " />
            </td>
            <td className="flex items-center justify-items-center gap-2">
              <button className="cursor-pointer min-w-[30px] min-h-[30px] flex items-center justify-center gap-2 bg-red-200 p-2 rounded-md">
                <FiTrash2 className="w-[20px] h-[20px] text-red-400" />{" "}
                <span className="text-red-400 hidden xl:block">Delete</span>
              </button>
              <button className="cursor-pointer min-w-[30px] min-h-[30px] flex items-center justify-center gap-2 bg-blue-200 p-2 rounded-md">
                <FaRegEdit className="w-[20px] h-[20px] text-blue-400" />{" "}
                <span className="text-blue-400  hidden xl:block">Edit</span>
              </button>
              <button className="flex items-center justify-center bg-red-700 min-w-[30px] min-h-[30px] text-white  p-2 rounded-md gap-2">
                <FaRegFilePdf className="w-[20px] h-[20px]" />
                <span className=" hidden xl:block">Create PDF</span>
              </button>
              <button className="flex items-center justify-center bg-emerald-600 min-w-[30px] min-h-[30px] text-white  p-2 rounded-md gap-2">
                <FiPrinter className="w-[20px] h-[20px]" />
                <span className=" hidden xl:block">Print</span>
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default TableList;
