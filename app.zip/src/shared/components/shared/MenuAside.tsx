"use client";

import {
  SlBookOpen,
  SlDirections,
  SlLayers,
  SlLogin,
  SlNote,
  SlOptions,
  SlPeople,
  SlSettings,
  SlUser,
} from "react-icons/sl";
import { TbPointFilled } from "react-icons/tb";
import SidebarSection from "./SidebarSection";
import Link from "next/link";
import { FC, useEffect } from "react";
import { useSidebarStore } from "../../stores/useSidebarStore";
import { IoCloseOutline } from "react-icons/io5";
import { generalReactClass } from "@/shared/types/TGeneral";
import { usePathname } from "next/navigation";
import { HiOutlineServer } from "react-icons/hi2";

const MenuAside: FC<generalReactClass> = ({ className }) => {
  const isSidebarOpen = useSidebarStore((state) => state.isSidebarOpen);
  const closeSidebar = useSidebarStore((state) => state.closeSidebar);
  const pathname = usePathname();
  const cleanPath = pathname?.replace(/^\/(es|en|fr)(\/|$)/, "/");

  // ✅ Todas tus rutas reales definidas abajo
  const ordersLinks = [
    {
      label: "Work orders",
      href: "/dashboard/orders/work-orders",
      icon: <SlBookOpen />,
    },
    {
      label: "Inspections",
      href: "#",
      icon: <SlNote />,
    },
  ];

  const inspectionsLinks = [
    {
      label: "Inspection configuration",
      href: "/dashboard/inspections/inspection-configuration",
      icon: <SlSettings />,
    },
    {
      label: "Clients",
      href: "/dashboard/inspections/clients",
      icon: <SlPeople />,
    },
    {
      label: "Services",
      href: "/dashboard/inspections/services",
      icon: <HiOutlineServer />,
    },
    {
      label: "Groups",
      href: "/dashboard/inspections/groups",
      icon: <SlLayers />,
    },
    {
      label: "Users",
      href: "/dashboard/inspections/users",
      icon: <SlUser />,
    },
  ];

  const configurationLinks = [
    {
      label: "Configurations",
      href: "#",
      icon: <SlSettings />,
    },
    {
      label: "IC theme",
      href: "/dashboard/configurations/ic-theme",
      icon: <SlDirections />,
    },
  ];

  const allLinks = [...ordersLinks, ...inspectionsLinks, ...configurationLinks];

  const activeHref =
    allLinks
      .filter(
        (link) =>
          cleanPath === link.href || cleanPath?.startsWith(link.href + "/")
      )
      .sort((a, b) => b.href.length - a.href.length)[0]?.href ?? undefined;

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024 && isSidebarOpen) {
        closeSidebar();
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize();

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, [isSidebarOpen, closeSidebar]);

  return (
    <aside
      className={`bg-[#191917] ${
        !isSidebarOpen ? `min-w-[300px]` : `w-full`
      } flex flex-row  ${className}`}
    >
      <div className="flex-1 h-full flex flex-col">
        {/* HEADER */}
        <div
          className="title w-full h-[60px] flex items-center justify-between px-4 gap-3"
          style={{ borderBottom: "1px solid #ffffff17" }}
        >
          <div className="flex flex-row items-center gap-2">
            <div className="avatar avatar-online">
              <div className="w-10 rounded-full">
                <img src="https://img.daisyui.com/images/profile/demo/gordon@192.webp" />
              </div>
            </div>
            <div className="flex flex-col justify-center gap-[.5px]">
              <h1 className="text-white text-sm font-light">
                Neill Bryan Rivera Livia
              </h1>
              <span className="text-gray-500 text-xs">
                bryan.riv09@live.com
              </span>
            </div>
          </div>
          <div className="flex flex-row gap-3">
            <div className="dropdown dropdown-end">
              <button
                tabIndex={0}
                role="button"
                className="btn btn-square btn-neutral bg-[#ffffff1f] shadow-none border-none"
              >
                <SlOptions className="text-lg" />
              </button>
              <ul
                tabIndex={0}
                className="dropdown-content menu bg-zinc-800 rounded-box z-1 w-52 shadow-sm"
                style={{ border: "1px solid #ffffff17" }}
              >
                <li>
                  <Link
                    href="#"
                    className="text-white min-h-[40px] flex items-center justify-start hover:text-white hover:pl-5 transition-all"
                  >
                    Opcion 1
                  </Link>
                </li>
              </ul>
            </div>
            <button
              role="button"
              onClick={closeSidebar}
              className="btn btn-square btn-neutral bg-[#ffffff1f] shadow-none border-none flex lg:hidden"
            >
              <IoCloseOutline className="text-2xl" />
            </button>
          </div>
        </div>

        {/* BODY */}
        <div className="flex-1 flex flex-col overflow-y-auto">
          <div className="dashboard-info p-5 flex flex-col gap-2 min-h-[78px]">
            <div className="flex items-center justify-start gap-2">
              <p className="text-white font-medium tracking-[1px] text-xl">
                Dashboard
              </p>
              <p className="bg-red-400 text-white text-xs px-2 w-[23px] h-[14px] flex items-center justify-center rounded-full shadow-2xl">
                <span className="relative top-[1px]">12</span>
              </p>
            </div>
            <div className="flex flex-row gap-2 text-white text-sm font-light tracking-[.5px] items-center justify-start">
              <div>
                12,231 <span className="text-emerald-500 ">Inspections</span>
              </div>
              <TbPointFilled className="text-xs text-shadow-emerald-800" />
              <div>
                12,214 <span className="text-emerald-500">Orders</span>
              </div>
            </div>
          </div>

          <nav className="p-5 flex flex-1 flex-col">
            <SidebarSection
              title="Orders"
              links={ordersLinks}
              activeHref={activeHref}
            />
            <SidebarSection
              title="Inspections"
              links={inspectionsLinks}
              activeHref={activeHref}
            />
            <SidebarSection
              title="Configuration"
              links={configurationLinks}
              activeHref={activeHref}
            />
          </nav>
        </div>

        {/* FOOTER */}
        <div
          className="sign-out min-h-[50px] px-4 flex items-row items-center justify-between"
          style={{ borderTop: "1px solid #ffffff17" }}
        >
          <div className="flex items-center justify-center">
            <button className="btn btn-square btn-neutral bg-transparent shadow-none border-none">
              <SlLogin className="text-lg" />
            </button>
            <span className="text-white">Sign Out</span>
          </div>
          <div>
            <span className="text-sm text-gray-400">Version 0.0.1</span>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default MenuAside;
