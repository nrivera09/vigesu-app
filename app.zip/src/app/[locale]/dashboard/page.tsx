import BoxContent from "@/shared/components/BoxContent";
import React from "react";

const page = () => {
  return (
    <>
      <BoxContent>d</BoxContent>
    </>
  );
};

export default page;
