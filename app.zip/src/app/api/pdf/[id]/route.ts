import { html2pdf } from "html2pdf-ts";
import { NextRequest } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import os from "os";

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url);
    const id = url.pathname.split("/").pop();
    if (!id) return new Response("ID missing", { status: 400 });

    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
    const pdfUrl = `${baseUrl}/es/dashboard/orders/work-orders/generate-pdf/${id}?preview=true`;

    console.log("📄 Generating PDF for:", pdfUrl);

    const options = {
      format: "A4",
      landscape: false,
      resolution: { width: 1080, height: 1920 },
      // protect: { password: "secret" }, // opcional
    };

    const html = await fetch(pdfUrl).then((r) => r.text());
    const filePath = path.join(os.tmpdir(), `WorkOrder-${id}.pdf`);

    await html2pdf.createPDF(html, { ...options, filePath });

    const file = await fs.readFile(filePath);
    await fs.unlink(filePath);

    return new Response(file, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="WorkOrder-${id}.pdf"`,
      },
    });
  } catch (err) {
    console.error("❌ PDF gen error:", err);
    return new Response("Internal Server Error", { status: 500 });
  }
}
