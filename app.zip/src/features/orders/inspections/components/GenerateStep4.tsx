import React from "react";
import Wizard from "./Wizard";

const GenerateStep4 = () => {
  return (
    <>
      <Wizard /> <div>GenerateStep4</div>
    </>
  );
};

export default GenerateStep4;
