export const COMPANY_INFO = {
  name: "Visegu",
  phone: "(510) 719-1444",
  email: "percyruiz@visegu.com",
  website: "www.visegu.com",
  address: "16198 Via Arriba San Lorezo, CA 94585",
};
export const DOMAIN = "https://ronnyruiz-001-site1.qtempurl.com/";
