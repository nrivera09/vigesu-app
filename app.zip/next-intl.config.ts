const config = {
  locales: ["en", "es"],
  defaultLocale: "es",
  localePrefix: "as-needed", // o 'always'
};

export default config;
